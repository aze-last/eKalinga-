using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AttendanceShiftingManagement.Models
{
    [Table("ayuda_programs")]
    public class AyudaProgram
    {
        public Guid SyncId { get; set; } = Guid.NewGuid();

        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("program_code")]
        [Required]
        [MaxLength(40)]
        public string ProgramCode { get; set; } = string.Empty;

        [Column("program_name")]
        [Required]
        [MaxLength(150)]
        public string ProgramName { get; set; } = string.Empty;

        [Column("program_type")]
        public AyudaProgramType ProgramType { get; set; } = AyudaProgramType.GeneralPurpose;

        [Column("description")]
        [MaxLength(500)]
        public string? Description { get; set; }

        [Column("assistance_type")]
        [MaxLength(120)]
        public string? AssistanceType { get; set; }

        [Column("release_kind", TypeName = "varchar(32)")]
        public AssistanceReleaseKind ReleaseKind { get; set; } = AssistanceReleaseKind.Cash;

        [Column("unit_amount", TypeName = "decimal(18,2)")]
        public decimal? UnitAmount { get; set; }

        [Column("item_description")]
        [MaxLength(250)]
        public string? ItemDescription { get; set; }

        [Column("item_name")]
        [MaxLength(100)]
        public string? ItemName { get; set; }

        [Column("quantity_per_beneficiary", TypeName = "decimal(18,2)")]
        public decimal? QuantityPerBeneficiary { get; set; }

        [Column("unit_of_measure")]
        [MaxLength(30)]
        public string? UnitOfMeasure { get; set; }

        [Column("start_date")]
        public DateTime? StartDate { get; set; }

        [Column("end_date")]
        public DateTime? EndDate { get; set; }

        [Column("budget_cap", TypeName = "decimal(18,2)")]
        public decimal? BudgetCap { get; set; }

        [Column("distribution_status")]
        public AyudaProgramDistributionStatus DistributionStatus { get; set; } = AyudaProgramDistributionStatus.Draft;

        [Column("is_active")]
        public bool IsActive { get; set; } = true;

        [Column("created_by_user_id")]
        public int CreatedByUserId { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        [Column("source_donation_id")]
        public int? SourceDonationId { get; set; }

        [Column("source_ggms_budget_id")]
        public int? SourceGGMSBudgetId { get; set; }

        /// <summary>
        /// GGMS project_details.project_details_id (e.g. OPP-2026-0006) this program draws from.
        /// Set when the program is created from a mirrored GGMS project in the Budget module.
        /// </summary>
        [Column("source_project_details_id")]
        [MaxLength(45)]
        public string? SourceProjectDetailsId { get; set; }

        [ForeignKey(nameof(SourceDonationId))]
        public PrivateDonation? SourceDonation { get; set; }

        [ForeignKey(nameof(SourceGGMSBudgetId))]
        public GovernmentBudgetSnapshot? SourceGGMSBudget { get; set; }

        [NotMapped]
        public decimal? LinkedFundingAmount => SourceDonation?.Amount ?? SourceGGMSBudget?.AllocatedAmount;

        /// <summary>
        /// Funding-source display code for the payout console footer:
        /// GGMS project id when linked, else the donation/GGMS stream label.
        /// </summary>
        [NotMapped]
        public string FundSourceCode
        {
            get
            {
                if (!string.IsNullOrEmpty(SourceProjectDetailsId))
                    return SourceProjectDetailsId;
                if (SourceDonationId.HasValue)
                    return "Private Donation";
                if (SourceGGMSBudgetId.HasValue)
                    return "GGMS Budget";
                return "General Fund";
            }
        }
    }

    [Table("assistance_case_budgets")]
    public class AssistanceCaseBudget
    {
        public Guid SyncId { get; set; } = Guid.NewGuid();

        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("budget_code")]
        [Required]
        [MaxLength(40)]
        public string BudgetCode { get; set; } = string.Empty;

        [Column("budget_name")]
        [Required]
        [MaxLength(150)]
        public string BudgetName { get; set; } = string.Empty;

        [Column("description")]
        [MaxLength(500)]
        public string? Description { get; set; }

        [Column("assistance_type")]
        [MaxLength(120)]
        public string? AssistanceType { get; set; }

        [Column("budget_cap", TypeName = "decimal(18,2)")]
        public decimal? BudgetCap { get; set; }

        [Column("is_active")]
        public bool IsActive { get; set; } = true;

        [Column("created_by_user_id")]
        public int CreatedByUserId { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; } = DateTime.Now;
    }

    [Table("cash_for_work_budgets")]
    public class CashForWorkBudget
    {
        public Guid SyncId { get; set; } = Guid.NewGuid();

        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("budget_code")]
        [Required]
        [MaxLength(40)]
        public string BudgetCode { get; set; } = string.Empty;

        [Column("budget_name")]
        [Required]
        [MaxLength(150)]
        public string BudgetName { get; set; } = string.Empty;

        [Column("description")]
        [MaxLength(500)]
        public string? Description { get; set; }

        [Column("budget_cap", TypeName = "decimal(18,2)")]
        public decimal? BudgetCap { get; set; }

        [Column("is_active")]
        public bool IsActive { get; set; } = true;

        [Column("created_by_user_id")]
        public int CreatedByUserId { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        [Column("source_donation_id")]
        public int? SourceDonationId { get; set; }

        [Column("source_ggms_budget_id")]
        public int? SourceGGMSBudgetId { get; set; }

        [Column("source_project_details_id")]
        [MaxLength(45)]
        public string? SourceProjectDetailsId { get; set; }

        [Column("daily_rate", TypeName = "decimal(18,2)")]
        public decimal? DailyRate { get; set; }

        [Column("start_date")]
        public DateTime? StartDate { get; set; }

        [Column("end_date")]
        public DateTime? EndDate { get; set; }

        [ForeignKey(nameof(SourceDonationId))]
        public PrivateDonation? SourceDonation { get; set; }

        [ForeignKey(nameof(SourceGGMSBudgetId))]
        public GovernmentBudgetSnapshot? SourceGGMSBudget { get; set; }
    }

    [Table("ayuda_project_beneficiaries")]
    public class AyudaProjectBeneficiary
    {
        public Guid SyncId { get; set; } = Guid.NewGuid();

        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("ayuda_program_id")]
        public int AyudaProgramId { get; set; }

        [Column("beneficiary_staging_id")]
        public int BeneficiaryStagingId { get; set; }

        [Column("household_id")]
        public int? HouseholdId { get; set; }

        [Column("household_member_id")]
        public int? HouseholdMemberId { get; set; }

        [Column("beneficiary_id")]
        [MaxLength(120)]
        public string? BeneficiaryId { get; set; }

        [Column("civil_registry_id")]
        [MaxLength(120)]
        public string? CivilRegistryId { get; set; }

        [Column("full_name")]
        [Required]
        [MaxLength(200)]
        public string FullName { get; set; } = string.Empty;

        [Column("status")]
        public DistributionBeneficiaryStatus Status { get; set; } = DistributionBeneficiaryStatus.Pending;

        [Column("status_reason")]
        [MaxLength(1000)]
        public string? StatusReason { get; set; }

        [Column("status_updated_by_user_id")]
        public int? StatusUpdatedByUserId { get; set; }

        [Column("status_updated_at")]
        public DateTime? StatusUpdatedAt { get; set; }

        [Column("added_by_user_id")]
        public int AddedByUserId { get; set; }

        [Column("added_at")]
        public DateTime AddedAt { get; set; } = DateTime.Now;

        [ForeignKey(nameof(AyudaProgramId))]
        public AyudaProgram? AyudaProgram { get; set; }
    }

    [Table("ayuda_project_claims")]
    public class AyudaProjectClaim
    {
        public Guid SyncId { get; set; } = Guid.NewGuid();

        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("ayuda_program_id")]
        public int AyudaProgramId { get; set; }

        [Column("beneficiary_staging_id")]
        public int BeneficiaryStagingId { get; set; }

        [Column("project_beneficiary_id")]
        public int? ProjectBeneficiaryId { get; set; }

        [Column("household_id")]
        public int? HouseholdId { get; set; }

        [Column("household_member_id")]
        public int? HouseholdMemberId { get; set; }

        [Column("beneficiary_id")]
        [MaxLength(120)]
        public string? BeneficiaryId { get; set; }

        [Column("civil_registry_id")]
        [MaxLength(120)]
        public string? CivilRegistryId { get; set; }

        [Column("full_name")]
        [Required]
        [MaxLength(200)]
        public string FullName { get; set; } = string.Empty;

        [Column("assistance_type_snapshot")]
        [MaxLength(120)]
        public string? AssistanceTypeSnapshot { get; set; }

        [Column("item_description_snapshot")]
        [MaxLength(250)]
        public string? ItemDescriptionSnapshot { get; set; }

        [Column("item_name_snapshot")]
        [MaxLength(100)]
        public string? ItemNameSnapshot { get; set; }

        [Column("quantity_snapshot", TypeName = "decimal(18,2)")]
        public decimal? QuantitySnapshot { get; set; }

        [Column("unit_of_measure_snapshot")]
        [MaxLength(30)]
        public string? UnitOfMeasureSnapshot { get; set; }

        [Column("unit_amount_snapshot", TypeName = "decimal(18,2)")]
        public decimal? UnitAmountSnapshot { get; set; }

        [Column("qr_payload")]
        [MaxLength(200)]
        public string? QrPayload { get; set; }

        [Column("remarks")]
        [MaxLength(1000)]
        public string? Remarks { get; set; }

        [Column("claimed_by_user_id")]
        public int ClaimedByUserId { get; set; }

        [Column("claimed_at")]
        public DateTime ClaimedAt { get; set; } = DateTime.Now;

        [Column("is_deleted")]
        public bool IsDeleted { get; set; } = false;

        [ForeignKey(nameof(AyudaProgramId))]
        public AyudaProgram? AyudaProgram { get; set; }
    }

    [Table("beneficiary_community_tax_payments")]
    public class BeneficiaryCommunityTaxPayment
    {
        public Guid SyncId { get; set; } = Guid.NewGuid();

        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("beneficiary_staging_id")]
        [Required]
        public int BeneficiaryStagingId { get; set; }

        [Column("ayuda_program_id")]
        public int? AyudaProgramId { get; set; }

        [Column("cedula_number")]
        [MaxLength(50)]
        public string CedulaNumber { get; set; } = string.Empty;

        [Column("paid_amount", TypeName = "decimal(18,2)")]
        public decimal? PaidAmount { get; set; }

        [Column("paid_date")]
        public DateTime? PaidDate { get; set; }

        [Column("is_deleted")]
        public bool IsDeleted { get; set; } = false;

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }

    [Table("beneficiary_requirement_documents")]
    public class BeneficiaryRequirementDocument
    {
        public Guid SyncId { get; set; } = Guid.NewGuid();

        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("beneficiary_staging_id")]
        [Required]
        public int BeneficiaryStagingId { get; set; }

        [Column("ayuda_program_id")]
        public int? AyudaProgramId { get; set; }

        [Column("document_name")]
        [MaxLength(100)]
        public string DocumentName { get; set; } = string.Empty;

        [Column("submitted_date")]
        public DateTime? SubmittedDate { get; set; }

        [Column("status")]
        [MaxLength(20)]
        public string Status { get; set; } = "Incomplete";

        [Column("remarks")]
        [MaxLength(500)]
        public string? Remarks { get; set; }

        [Column("is_deleted")]
        public bool IsDeleted { get; set; } = false;

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [ForeignKey(nameof(AyudaProgramId))]
        public AyudaProgram? AyudaProgram { get; set; }
    }

    [Table("ayuda_project_budget_sources")]
    public class ProjectBudgetSource
    {
        public Guid SyncId { get; set; } = Guid.NewGuid();

        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("ayuda_program_id")]
        public int AyudaProgramId { get; set; }

        [Column("budget_bucket_id")]
        public int BudgetBucketId { get; set; }

        [Column("budget_bucket_type")]
        [MaxLength(50)]
        public string BudgetBucketType { get; set; } = string.Empty; // "AssistanceCase", "CashForWork", "Government", "Private"

        [Column("priority")]
        public int Priority { get; set; }

        [ForeignKey(nameof(AyudaProgramId))]
        public AyudaProgram? AyudaProgram { get; set; }
    }

    [Table("government_budget_snapshots")]
    public class GovernmentBudgetSnapshot
    {
        public Guid SyncId { get; set; } = Guid.NewGuid();

        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("office_code")]
        [Required]
        [MaxLength(40)]
        public string OfficeCode { get; set; } = string.Empty;

        [Column("office_name")]
        [Required]
        [MaxLength(120)]
        public string OfficeName { get; set; } = string.Empty;

        [Column("yearly_budget_id")]
        public int YearlyBudgetId { get; set; }

        [Column("allocated_amount", TypeName = "decimal(18,2)")]
        public decimal AllocatedAmount { get; set; }

        [Column("spent_amount", TypeName = "decimal(18,2)")]
        public decimal SpentAmount { get; set; }

        [Column("source_row_id")]
        [MaxLength(80)]
        public string? SourceRowId { get; set; }

        [Column("sync_status")]
        public GovernmentBudgetSyncStatus SyncStatus { get; set; } = GovernmentBudgetSyncStatus.Synced;

        [Column("synced_at")]
        public DateTime SyncedAt { get; set; } = DateTime.Now;

        [Column("target_program_id")]
        public int? TargetProgramId { get; set; }

        [Column("target_assistance_case_budget_id")]
        public int? TargetAssistanceCaseBudgetId { get; set; }

        [Column("target_cash_for_work_budget_id")]
        public int? TargetCashForWorkBudgetId { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [Column("updated_at")]
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        [ForeignKey(nameof(TargetProgramId))]
        public AyudaProgram? TargetProgram { get; set; }

        [ForeignKey(nameof(TargetAssistanceCaseBudgetId))]
        public AssistanceCaseBudget? TargetAssistanceCaseBudget { get; set; }

        [ForeignKey(nameof(TargetCashForWorkBudgetId))]
        public CashForWorkBudget? TargetCashForWorkBudget { get; set; }
    }

    [Table("private_donations")]
    public class PrivateDonation
    {
        public Guid SyncId { get; set; } = Guid.NewGuid();

        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("donor_type")]
        public PrivateDonationDonorType DonorType { get; set; } = PrivateDonationDonorType.Person;

        [Column("donor_name")]
        [Required]
        [MaxLength(180)]
        public string DonorName { get; set; } = string.Empty;

        [Column("donation_type")]
        public DonationType DonationType { get; set; } = DonationType.Cash;

        [Column("amount", TypeName = "decimal(18,2)")]
        public decimal Amount { get; set; }

        [Column("item_name")]
        [MaxLength(100)]
        public string? ItemName { get; set; }

        [Column("quantity", TypeName = "decimal(18,2)")]
        public decimal? Quantity { get; set; }

        [Column("unit_of_measure")]
        [MaxLength(30)]
        public string? UnitOfMeasure { get; set; }

        [Column("date_received")]
        public DateTime DateReceived { get; set; } = DateTime.Today;

        [Column("reference_number")]
        [MaxLength(80)]
        public string? ReferenceNumber { get; set; }

        [Column("remarks")]
        [MaxLength(1000)]
        public string? Remarks { get; set; }

        [Column("proof_type")]
        public DonationProofType ProofType { get; set; } = DonationProofType.Cash;

        [Column("proof_reference_number")]
        [MaxLength(80)]
        public string? ProofReferenceNumber { get; set; }

        [Column("proof_file_path")]
        [MaxLength(255)]
        public string? ProofFilePath { get; set; }

        [Column("received_by_user_id")]
        public int ReceivedByUserId { get; set; }

        [Column("target_program_id")]
        public int? TargetProgramId { get; set; }

        [Column("target_assistance_case_budget_id")]
        public int? TargetAssistanceCaseBudgetId { get; set; }

        [Column("target_cash_for_work_budget_id")]
        public int? TargetCashForWorkBudgetId { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [ForeignKey(nameof(TargetProgramId))]
        public AyudaProgram? TargetProgram { get; set; }

        [ForeignKey(nameof(TargetAssistanceCaseBudgetId))]
        public AssistanceCaseBudget? TargetAssistanceCaseBudget { get; set; }

        [ForeignKey(nameof(TargetCashForWorkBudgetId))]
        public CashForWorkBudget? TargetCashForWorkBudget { get; set; }
    }

    [Table("budget_ledger_entries")]
    public class BudgetLedgerEntry
    {
        public Guid SyncId { get; set; } = Guid.NewGuid();
        public DateTime UpdatedAt { get; set; } = DateTime.Now;

        [Key]
        [Column("id")]
        public int Id { get; set; }

        [Column("entry_type")]
        public BudgetLedgerEntryType EntryType { get; set; } = BudgetLedgerEntryType.Release;

        [Column("feature_source")]
        public BudgetLedgerFeatureSource FeatureSource { get; set; } = BudgetLedgerFeatureSource.BudgetModule;

        [Column("source_record_id")]
        [MaxLength(80)]
        public string SourceRecordId { get; set; } = string.Empty;

        [Column("program_id")]
        public int? ProgramId { get; set; }

        [Column("assistance_case_budget_id")]
        public int? AssistanceCaseBudgetId { get; set; }

        [Column("cash_for_work_budget_id")]
        public int? CashForWorkBudgetId { get; set; }

        [Column("recipient_count")]
        public int RecipientCount { get; set; }

        [Column("total_amount", TypeName = "decimal(18,2)")]
        public decimal TotalAmount { get; set; }

        [Column("government_portion", TypeName = "decimal(18,2)")]
        public decimal GovernmentPortion { get; set; }

        [Column("private_portion", TypeName = "decimal(18,2)")]
        public decimal PrivatePortion { get; set; }

        [Column("entry_date")]
        public DateTime EntryDate { get; set; } = DateTime.Today;

        [Column("remarks")]
        [MaxLength(1000)]
        public string? Remarks { get; set; }

        [Column("release_kind", TypeName = "varchar(32)")]
        public AssistanceReleaseKind? ReleaseKind { get; set; }

        [Column("recorded_by_user_id")]
        public int RecordedByUserId { get; set; }

        [Column("created_at")]
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        [ForeignKey(nameof(ProgramId))]
        public AyudaProgram? Program { get; set; }

        [ForeignKey(nameof(AssistanceCaseBudgetId))]
        public AssistanceCaseBudget? AssistanceCaseBudget { get; set; }

        [ForeignKey(nameof(CashForWorkBudgetId))]
        public CashForWorkBudget? CashForWorkBudget { get; set; }
    }

    public enum AyudaProgramType
    {
        AssistanceCase,
        CashForWork,
        GeneralPurpose,
        Seminar
    }

    public enum AyudaProgramDistributionStatus
    {
        Draft,
        Open,
        Closed
    }

    public enum DistributionBeneficiaryStatus
    {
        Pending,
        Released,
        Rejected
    }

    public enum GovernmentBudgetSyncStatus
    {
        Synced,
        MissingConfiguration,
        Failed
    }

    public enum PrivateDonationDonorType
    {
        Person,
        Organization
    }

    public enum DonationType
    {
        Cash,
        Goods
    }

    public enum DonationProofType
    {
        Cash,
        Check,
        Voucher,
        BankTransfer,
        Other
    }

    public enum BudgetLedgerEntryType
    {
        Donation,
        Release,
        Reallocation,
        GoodsDonation
    }

    public enum BudgetLedgerFeatureSource
    {
        BudgetModule,
        AssistanceCase,
        CashForWork,
        ProjectDistribution,
        ManualAssistance
    }
}
