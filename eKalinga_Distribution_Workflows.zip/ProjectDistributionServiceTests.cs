using AttendanceShiftingManagement.Data;
using AttendanceShiftingManagement.Models;
using AttendanceShiftingManagement.Services;
using Microsoft.EntityFrameworkCore;
using System.Reflection;

namespace AttendanceShiftingManagement.Tests;

public sealed class ProjectDistributionServiceTests
{
    [Fact]
    public async Task AddBeneficiaryAsync_AddsApprovedBeneficiaryToProject_AndBlocksDuplicateMembership()
    {
        using var context = TestDbContextFactory.CreateContext();
        var admin = SeedAdmin(context);
        var program = SeedProgram(context, admin.Id);
        var beneficiary = SeedApprovedBeneficiary(context);

        var service = CreateService(context);

        var firstResult = await InvokeAsync(service, "AddBeneficiaryAsync", program.Id, beneficiary.StagingID, admin.Id);
        Assert.True(GetBool(firstResult, "IsSuccess"));

        var duplicateResult = await InvokeAsync(service, "AddBeneficiaryAsync", program.Id, beneficiary.StagingID, admin.Id);
        Assert.False(GetBool(duplicateResult, "IsSuccess"));

        Assert.Equal(1, GetEntityCount(context, "AttendanceShiftingManagement.Models.AyudaProjectBeneficiary"));
    }

    [Fact]
    public async Task EvaluateQualificationAsync_ReturnsQualifiedForIncludedBeneficiary_AndRejectedForNonMember()
    {
        using var context = TestDbContextFactory.CreateContext();
        var admin = SeedAdmin(context);
        var program = SeedProgram(context, admin.Id);
        var includedBeneficiary = SeedApprovedBeneficiary(context, 2001, "Juan Included");
        var excludedBeneficiary = SeedApprovedBeneficiary(context, 2002, "Maria Excluded");

        var service = CreateService(context);
        await InvokeAsync(service, "AddBeneficiaryAsync", program.Id, includedBeneficiary.StagingID, admin.Id);

        var includedResult = await InvokeAsync(service, "EvaluateQualificationAsync", program.Id, includedBeneficiary.StagingID);
        Assert.True(GetBool(includedResult, "IsQualified"));
        Assert.False(GetBool(includedResult, "AlreadyClaimed"));

        var excludedResult = await InvokeAsync(service, "EvaluateQualificationAsync", program.Id, excludedBeneficiary.StagingID);
        Assert.False(GetBool(excludedResult, "IsQualified"));
    }

    [Fact]
    public async Task EvaluateQualificationAsync_RecognizesIncludedBeneficiaryByBeneficiaryId_WhenDigitalIdUsesDifferentStagingRow()
    {
        using var context = TestDbContextFactory.CreateContext();
        var admin = SeedAdmin(context);
        var program = SeedProgram(context, admin.Id);
        var includedBeneficiary = SeedApprovedBeneficiary(context, 2101, "Bien Josef G. Regidor", beneficiaryId: "BEN-2026-MANUAL-40405", civilRegistryId: null);
        var scannedBeneficiary = SeedApprovedBeneficiary(context, 2102, "Bien Josef G. Regidor", beneficiaryId: "BEN-2026-MANUAL-40405", civilRegistryId: null);

        var service = CreateService(context);
        await InvokeAsync(service, "AddBeneficiaryAsync", program.Id, includedBeneficiary.StagingID, admin.Id);

        var qualification = await InvokeAsync(service, "EvaluateQualificationAsync", program.Id, scannedBeneficiary.StagingID);

        Assert.True(GetBool(qualification, "IsQualified"));
        Assert.True(GetBool(qualification, "IsIncluded"));
        Assert.True(GetBool(qualification, "CanRelease"));
    }

    [Fact]
    public async Task RecordClaimAsync_CreatesOneClaimPerProject_AndBlocksDuplicateClaim()
    {
        using var context = TestDbContextFactory.CreateContext();
        var admin = SeedAdmin(context);
        var program = SeedProgram(context, admin.Id, unitAmount: 1500m);
        var beneficiary = SeedApprovedBeneficiary(context);
        SeedGovernmentSnapshot(context, 5000m, 2, "OFF-2026-0006");

        var service = CreateService(context);
        await InvokeAsync(service, "AddBeneficiaryAsync", program.Id, beneficiary.StagingID, admin.Id);

        var firstClaim = await InvokeAsync(service, "RecordClaimAsync", program.Id, beneficiary.StagingID, admin.Id, "ASM-BID|000001|ABC", "Initial claim");
        Assert.True(GetBool(firstClaim, "IsSuccess"));

        var duplicateClaim = await InvokeAsync(service, "RecordClaimAsync", program.Id, beneficiary.StagingID, admin.Id, "ASM-BID|000001|ABC", "Duplicate claim");
        Assert.False(GetBool(duplicateClaim, "IsSuccess"));

        Assert.Equal(1, GetEntityCount(context, "AttendanceShiftingManagement.Models.AyudaProjectClaim"));
        Assert.Equal(1, context.BudgetLedgerEntries.Count(entry => entry.EntryType == BudgetLedgerEntryType.Release));
        Assert.Contains(
            context.BudgetLedgerEntries,
            entry => entry.FeatureSource == BudgetLedgerFeatureSource.ProjectDistribution &&
                     entry.TotalAmount == 1500m &&
                     entry.RecipientCount == 1);
    }

    [Fact]
    public async Task RecordClaimAsync_WhenCombinedBudgetIsInsufficient_ReturnsFailureWithoutClaimOrLedger()
    {
        using var context = TestDbContextFactory.CreateContext();
        var admin = SeedAdmin(context);
        var program = SeedProgram(context, admin.Id, unitAmount: 2500m);
        var beneficiary = SeedApprovedBeneficiary(context);
        SeedGovernmentSnapshot(context, 1000m, 2, "OFF-2026-0006");

        var service = CreateService(context);
        await InvokeAsync(service, "AddBeneficiaryAsync", program.Id, beneficiary.StagingID, admin.Id);

        var claimResult = await InvokeAsync(service, "RecordClaimAsync", program.Id, beneficiary.StagingID, admin.Id, "ASM-BID|000001|ABC", "Blocked claim");
        Assert.False(GetBool(claimResult, "IsSuccess"));

        Assert.Equal(0, GetEntityCount(context, "AttendanceShiftingManagement.Models.AyudaProjectClaim"));
        Assert.DoesNotContain(context.BudgetLedgerEntries, entry => entry.EntryType == BudgetLedgerEntryType.Release);
    }

    [Fact]
    public async Task RecordClaimAsync_ForNonCashDistribution_StillWritesBeneficiaryHistoryAndMarksReleased()
    {
        using var context = TestDbContextFactory.CreateContext();
        var admin = SeedAdmin(context);
        var program = SeedProgram(context, admin.Id, unitAmount: 0m, releaseKind: AssistanceReleaseKind.Goods);
        var beneficiary = SeedApprovedBeneficiary(context, 3001, "Nora Beneficiary");

        var service = CreateService(context);
        await InvokeAsync(service, "AddBeneficiaryAsync", program.Id, beneficiary.StagingID, admin.Id);

        var claimResult = await InvokeAsync(service, "RecordClaimAsync", program.Id, beneficiary.StagingID, admin.Id, "ASM-BID|003001|ABC", "Rice pack release");
        Assert.True(GetBool(claimResult, "IsSuccess"));

        Assert.Equal(1, GetEntityCount(context, "AttendanceShiftingManagement.Models.AyudaProjectClaim"));
        Assert.DoesNotContain(context.BudgetLedgerEntries, entry => entry.EntryType == BudgetLedgerEntryType.Release);

        var membership = context.AyudaProjectBeneficiaries.Single(item =>
            item.AyudaProgramId == program.Id &&
            item.BeneficiaryStagingId == beneficiary.StagingID);
        Assert.Equal(DistributionBeneficiaryStatus.Released, membership.Status);

        var historyEntry = Assert.Single(context.BeneficiaryAssistanceLedgerEntries);
        Assert.Equal(BeneficiaryAssistanceSourceModule.ProjectDistribution, historyEntry.SourceModule);
        Assert.Equal(0m, historyEntry.Amount);
        Assert.Equal("Rice pack release", historyEntry.Remarks);
    }

    [Fact]
    public async Task RecordClaimAsync_UsesIncludedMembershipIdentity_WhenScannerStagingDiffers()
    {
        using var context = TestDbContextFactory.CreateContext();
        var admin = SeedAdmin(context);
        var program = SeedProgram(context, admin.Id, unitAmount: 1200m);
        SeedGovernmentSnapshot(context, 5000m, 2, "OFF-2026-0007");
        var includedBeneficiary = SeedApprovedBeneficiary(context, 3101, "Bien Josef G. Regidor", beneficiaryId: "BEN-2026-MANUAL-40405", civilRegistryId: null);
        var scannedBeneficiary = SeedApprovedBeneficiary(context, 3102, "Bien Josef G. Regidor", beneficiaryId: "BEN-2026-MANUAL-40405", civilRegistryId: null);

        var service = CreateService(context);
        await InvokeAsync(service, "AddBeneficiaryAsync", program.Id, includedBeneficiary.StagingID, admin.Id);

        var claimResult = await InvokeAsync(service, "RecordClaimAsync", program.Id, scannedBeneficiary.StagingID, admin.Id, "ASM-BID|003102|ABC", "Identity fallback claim");
        Assert.True(GetBool(claimResult, "IsSuccess"));

        var claim = Assert.Single(context.AyudaProjectClaims);
        Assert.Equal(includedBeneficiary.StagingID, claim.BeneficiaryStagingId);
        Assert.Equal("BEN-2026-MANUAL-40405", claim.BeneficiaryId);
    }

    [Fact]
    public async Task GetHouseholdVerificationContextAsync_FlagsHouseholdMemberWhoReceivedSameAssistanceType_CrossProject()
    {
        using var context = TestDbContextFactory.CreateContext();
        var admin = SeedAdmin(context);

        var currentProgram = SeedProgram(context, admin.Id);
        currentProgram.AssistanceType = "Rice Subsidy";
        var otherProgram = SeedProgram(context, admin.Id);
        otherProgram.AssistanceType = "Rice Subsidy";
        context.SaveChanges();

        context.Households.Add(new Household { Id = 1, HouseholdCode = "HH-001", HeadName = "Pedro Cruz", AddressLine = "123 Mabini St" });
        context.HouseholdMembers.Add(new HouseholdMember { Id = 1, HouseholdId = 1, FullName = "Pedro Cruz", RelationshipToHead = "Head" });
        context.HouseholdMembers.Add(new HouseholdMember { Id = 2, HouseholdId = 1, FullName = "Maria Cruz", RelationshipToHead = "Spouse" });
        context.SaveChanges();

        // Scanned beneficiary is Pedro (linked to household 1, member 1 via SeedApprovedBeneficiary).
        var scanned = SeedApprovedBeneficiary(context, 3001, "Pedro Cruz");

        // Maria (member 2) already received the SAME assistance type from a DIFFERENT project.
        context.AyudaProjectClaims.Add(new AyudaProjectClaim
        {
            AyudaProgramId = otherProgram.Id,
            BeneficiaryStagingId = 3999,
            HouseholdId = 1,
            HouseholdMemberId = 2,
            FullName = "Maria Cruz",
            ClaimedByUserId = admin.Id,
            ClaimedAt = DateTime.Now
        });
        context.SaveChanges();

        var service = (ProjectDistributionService)CreateService(context);
        var householdContext = await service.GetHouseholdVerificationContextAsync(currentProgram.Id, scanned.StagingID);

        Assert.True(householdContext.HasHousehold);
        Assert.True(householdContext.AnyMemberAlreadyReceived);
        Assert.False(string.IsNullOrWhiteSpace(householdContext.WarningMessage));
        Assert.Equal(2, householdContext.Members.Count);
        Assert.Contains(householdContext.Members, m => m.FullName == "Maria Cruz" && m.AlreadyReceivedSameAssistanceType);
        Assert.Contains(householdContext.Members, m => m.FullName == "Pedro Cruz" && !m.AlreadyReceivedSameAssistanceType);
        Assert.Contains(householdContext.Members, m => m.FullName == "Pedro Cruz" && m.IsScannedBeneficiary);
    }

    [Fact]
    public async Task GetHouseholdVerificationContextAsync_NoHouseholdLink_ReturnsHasHouseholdFalse()
    {
        using var context = TestDbContextFactory.CreateContext();
        var admin = SeedAdmin(context);
        var program = SeedProgram(context, admin.Id);

        context.BeneficiaryStaging.Add(new BeneficiaryStaging
        {
            StagingID = 4001,
            BeneficiaryId = "BEN-4001",
            CivilRegistryId = "CR-4001",
            FullName = "Unlinked Person",
            VerificationStatus = VerificationStatus.Approved,
            LinkedHouseholdId = null,
            LinkedHouseholdMemberId = null,
            ReviewedAt = DateTime.Now
        });
        context.SaveChanges();

        var service = (ProjectDistributionService)CreateService(context);
        var householdContext = await service.GetHouseholdVerificationContextAsync(program.Id, 4001);

        Assert.False(householdContext.HasHousehold);
        Assert.False(householdContext.AnyMemberAlreadyReceived);
        Assert.Empty(householdContext.Members);
    }

    private static object CreateService(LocalDbContext context)
    {
        var serviceType = typeof(LocalDbContext).Assembly.GetType("AttendanceShiftingManagement.Services.ProjectDistributionService");
        Assert.NotNull(serviceType);

        var service = Activator.CreateInstance(serviceType!, context);
        Assert.NotNull(service);
        return service!;
    }

    private static async Task<object> InvokeAsync(object instance, string methodName, params object?[] args)
    {
        var method = instance.GetType().GetMethod(methodName, BindingFlags.Instance | BindingFlags.Public);
        Assert.NotNull(method);

        var task = method!.Invoke(instance, args) as Task;
        Assert.NotNull(task);
        await task!;

        var resultProperty = task!.GetType().GetProperty("Result");
        Assert.NotNull(resultProperty);
        return resultProperty!.GetValue(task)!;
    }

    private static bool GetBool(object instance, string propertyName)
    {
        var property = instance.GetType().GetProperty(propertyName, BindingFlags.Instance | BindingFlags.Public);
        Assert.NotNull(property);
        return (bool)(property!.GetValue(instance) ?? false);
    }

    private static int GetEntityCount(LocalDbContext context, string entityTypeName)
    {
        var entityType = typeof(LocalDbContext).Assembly.GetType(entityTypeName);
        Assert.NotNull(entityType);

        var setMethod = typeof(DbContext)
            .GetMethods(BindingFlags.Instance | BindingFlags.Public)
            .Single(method => method.Name == nameof(DbContext.Set) && method.IsGenericMethod && method.GetParameters().Length == 0)
            .MakeGenericMethod(entityType!);

        var queryable = setMethod.Invoke(context, null) as IQueryable;
        Assert.NotNull(queryable);
        return queryable!.Cast<object>().Count();
    }

    private static User SeedAdmin(LocalDbContext context)
    {
        var user = new User
        {
            Username = "distribution-admin",
            Email = "distribution-admin@barangay.local",
            PasswordHash = BCrypt.Net.BCrypt.HashPassword("Password123!"),
            Role = UserRole.Admin,
            IsActive = true
        };

        context.Users.Add(user);
        context.SaveChanges();
        return user;
    }

    private static AyudaProgram SeedProgram(LocalDbContext context, int createdByUserId, decimal unitAmount = 1000m, AssistanceReleaseKind releaseKind = AssistanceReleaseKind.Cash)
    {
        var program = new AyudaProgram
        {
            ProgramCode = $"DIST-{Guid.NewGuid():N}"[..12],
            ProgramName = "Project Distribution Program",
            ProgramType = AyudaProgramType.GeneralPurpose,
            Description = "Distribution workflow seed data",
            ReleaseKind = releaseKind,
            CreatedByUserId = createdByUserId,
            IsActive = true
        };

        var unitAmountProperty = typeof(AyudaProgram).GetProperty("UnitAmount");
        unitAmountProperty?.SetValue(program, unitAmount);

        context.AyudaPrograms.Add(program);
        context.SaveChanges();
        return program;
    }

    private static BeneficiaryStaging SeedApprovedBeneficiary(
        LocalDbContext context,
        int stagingId = 1001,
        string fullName = "Pedro Beneficiary",
        string? beneficiaryId = null,
        string? civilRegistryId = null)
    {
        var beneficiary = new BeneficiaryStaging
        {
            StagingID = stagingId,
            BeneficiaryId = beneficiaryId ?? $"BEN-{stagingId:D4}",
            CivilRegistryId = civilRegistryId ?? $"CR-{stagingId:D4}",
            FullName = fullName,
            VerificationStatus = VerificationStatus.Approved,
            LinkedHouseholdId = 1,
            LinkedHouseholdMemberId = 1,
            ReviewedAt = DateTime.Now
        };

        context.BeneficiaryStaging.Add(beneficiary);
        context.SaveChanges();
        return beneficiary;
    }

    private static void SeedGovernmentSnapshot(LocalDbContext context, decimal allocatedAmount, int yearlyBudgetId, string officeCode)
    {
        context.GovernmentBudgetSnapshots.Add(new GovernmentBudgetSnapshot
        {
            OfficeCode = officeCode,
            OfficeName = "Ayuda",
            YearlyBudgetId = yearlyBudgetId,
            AllocatedAmount = allocatedAmount,
            SpentAmount = 0m,
            SourceRowId = yearlyBudgetId.ToString(),
            SyncStatus = GovernmentBudgetSyncStatus.Synced,
            SyncedAt = DateTime.Now,
            CreatedAt = DateTime.Now,
            UpdatedAt = DateTime.Now
        });

        context.SaveChanges();
    }
}
