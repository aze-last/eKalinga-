﻿# eKalinga+ Login & Local Database Architecture Review

## 1. Context & Architecture Overview
eKalinga+ is a WPF desktop application (.NET 9) for barangay aid (ayuda) operations designed for offline-first resilience with online synchronization.

The system uses two primary database layers:
1. LocalDbContext (SQLite ams.db): Stored in %LocalAppData%\eKalingaPlus\ams.db. Used for all local operations, offline caches, local users, and authentication (AuthService).
2. AppDbContext (MySQL): Used for remote Hostinger database synchronization (SyncService), LAN mode, or multi-seat installations.

## 2. The Problem Encountered
When installing the application on end-user/client computers via Inno Setup and launching:
- Users were greeted with an error:
  "Database connection failed. No local database detected. Open Connection Settings and choose Remote or LAN. Database authentication failed. Invalid username or password. Check ConnectionSettings."
- The login button and bootstrap admin setup forms were disabled.

### Root Cause:
LoginViewModel.EnsureDatabaseReady() was invoking DatabaseInitializer.Initialize(...), which connects directly to the MySQL database preset (127.0.0.1:3306 with default credentials). Because client computers do not have a local MySQL daemon running, the MySQL connection attempt threw MySqlException (1045 Authentication Failed / Connection Refused).
This caught exception caused LoginViewModel to flag _isCompanySerialAccessValid = false and set the failure status, despite the fact that AuthService and InitialAdminSetupService exclusively query SQLite (LocalDbContext).

## 3. The Solution Applied
- Updated LoginViewModel.EnsureDatabaseReady() to ensure the local SQLite database is created and bootstrapped (LocalDbContext.Database.EnsureCreated() and SQLiteSchemaBootstrapper.EnsureSQLiteSchema(localDb)).
- Decoupled login screen initialization from MySQL AppDbContext.
- Remote MySQL synchronization remains untouched in SplashViewModel, SyncService, and SettingsToolsViewModel for when online connectivity is available.

## 4. Included Files in this Bundle
- CLAUDE.md - Overall project architecture and conventions
- GEMINI.md - Project UI and business logic constraints
- appsettings.template.json - Sanitized application settings template
- ViewModels/LoginViewModel.cs - Login UI logic and startup readiness check
- ViewModels/SplashViewModel.cs - App startup sequence, background MySQL check, theme
- Services/AuthService.cs - User credential validation (queries LocalDbContext)
- Services/InitialAdminSetupService.cs - Initial administrator bootstrap logic
- Services/ConnectionSettingsService.cs - Preset management (Local, LAN, Remote)
- Data/LocalDbContext.cs - SQLite database context definition
- Data/SQLiteSchemaBootstrapper.cs - SQLite table & index bootstrapper
- Data/DatabaseInitializer.cs - MySQL database migration & initialization runner
