using AttendanceShiftingManagement.Data;
using AttendanceShiftingManagement.Helpers;
using AttendanceShiftingManagement.Models;
using AttendanceShiftingManagement.Services;
using Microsoft.Extensions.Configuration;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;

namespace AttendanceShiftingManagement.ViewModels
{
    public class LoginViewModel : ObservableObject
    {
        private readonly AuthService _authService;
        private readonly RelayCommand _loginCommand;
        private readonly RelayCommand _createInitialAdminCommand;
        private readonly RelayCommand _toggleShowPasswordCommand;
        private string _usernameOrEmail = string.Empty;
        private string _password = string.Empty;
        private string _bootstrapFullName = "Barangay Administrator";
        private string _bootstrapUsername = "admin";
        private string _bootstrapEmail = "admin@barangay.local";
        private string _bootstrapPassword = string.Empty;
        private string _bootstrapConfirmPassword = string.Empty;
        private string _statusMessage = string.Empty;
        private Brush _statusBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#6B7280"));
        private string _activeConnectionSummary = string.Empty;
        private bool _isBootstrapMode;
        private string _brandTitle = "Local Government Unit";
        private string _brandSubtitle = string.Empty;
        private string _brandAddress = string.Empty;
        private string _brandInstallSerial = string.Empty;
        private ImageSource? _brandLogoImage;
        private ImageSource? _brandBackgroundImage;
        private bool _isCompanySerialAccessValid = true;
        private bool _isShowingPassword;
        private bool _isOtpEnabled;

        public string UsernameOrEmail
        {
            get => _usernameOrEmail;
            set
            {
                if (SetProperty(ref _usernameOrEmail, value))
                {
                    _loginCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string Password
        {
            get => _password;
            set
            {
                if (SetProperty(ref _password, value))
                {
                    _loginCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string BootstrapFullName
        {
            get => _bootstrapFullName;
            set
            {
                if (SetProperty(ref _bootstrapFullName, value))
                {
                    _createInitialAdminCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string BootstrapUsername
        {
            get => _bootstrapUsername;
            set
            {
                if (SetProperty(ref _bootstrapUsername, value))
                {
                    _createInitialAdminCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string BootstrapEmail
        {
            get => _bootstrapEmail;
            set
            {
                if (SetProperty(ref _bootstrapEmail, value))
                {
                    _createInitialAdminCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string BootstrapPassword
        {
            get => _bootstrapPassword;
            set
            {
                if (SetProperty(ref _bootstrapPassword, value))
                {
                    _createInitialAdminCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string BootstrapConfirmPassword
        {
            get => _bootstrapConfirmPassword;
            set
            {
                if (SetProperty(ref _bootstrapConfirmPassword, value))
                {
                    _createInitialAdminCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            private set => SetProperty(ref _statusMessage, value);
        }

        public Brush StatusBrush
        {
            get => _statusBrush;
            private set => SetProperty(ref _statusBrush, value);
        }

        public string ActiveConnectionSummary
        {
            get => _activeConnectionSummary;
            set => SetProperty(ref _activeConnectionSummary, value);
        }

        public string BrandTitle
        {
            get => _brandTitle;
            private set => SetProperty(ref _brandTitle, value);
        }

        public string BrandSubtitle
        {
            get => _brandSubtitle;
            private set => SetProperty(ref _brandSubtitle, value);
        }

        public string BrandAddress
        {
            get => _brandAddress;
            private set
            {
                if (SetProperty(ref _brandAddress, value))
                {
                    OnPropertyChanged(nameof(HasBrandAddress));
                }
            }
        }

        public bool HasBrandAddress => !string.IsNullOrWhiteSpace(BrandAddress);

        public string BrandInstallSerial
        {
            get => _brandInstallSerial;
            private set
            {
                if (SetProperty(ref _brandInstallSerial, value))
                {
                    OnPropertyChanged(nameof(BrandInstallSerialLabel));
                }
            }
        }

        public string BrandInstallSerialLabel => $"Company Serial: {BrandInstallSerial}";

        public ImageSource? BrandLogoImage
        {
            get => _brandLogoImage;
            private set
            {
                if (SetProperty(ref _brandLogoImage, value))
                {
                    OnPropertyChanged(nameof(HasCustomBrandLogo));
                }
            }
        }

        public bool HasCustomBrandLogo => BrandLogoImage != null;

        public ImageSource? BrandBackgroundImage
        {
            get => _brandBackgroundImage;
            private set
            {
                if (SetProperty(ref _brandBackgroundImage, value))
                {
                    OnPropertyChanged(nameof(HasBrandBackgroundImage));
                }
            }
        }

        public bool HasBrandBackgroundImage => BrandBackgroundImage != null;

        public bool IsShowingPassword
        {
            get => _isShowingPassword;
            set => SetProperty(ref _isShowingPassword, value);
        }

        public bool IsBootstrapMode
        {
            get => _isBootstrapMode;
            private set
            {
                if (SetProperty(ref _isBootstrapMode, value))
                {
                    OnPropertyChanged(nameof(IsLoginMode));
                    OnPropertyChanged(nameof(FormTitle));
                    OnPropertyChanged(nameof(FormSubtitle));
                    _loginCommand.RaiseCanExecuteChanged();
                    _createInitialAdminCommand.RaiseCanExecuteChanged();
                }
            }
        }

        public bool IsLoginMode => !IsBootstrapMode;
        public string FormTitle => IsBootstrapMode ? "Initial Admin Setup" : "Admin Login";
        public string FormSubtitle => IsBootstrapMode
            ? "Create the first admin account for the selected database."
            : "Sign in to manage barangay operations.";

        public ICommand LoginCommand => _loginCommand;
        public ICommand CreateInitialAdminCommand => _createInitialAdminCommand;

        public LoginViewModel()
        {
            _authService = new AuthService();
            _loginCommand = new RelayCommand(ExecuteLogin, CanExecuteLogin);
            _createInitialAdminCommand = new RelayCommand(ExecuteCreateInitialAdmin, CanCreateInitialAdmin);
            _toggleShowPasswordCommand = new RelayCommand(ExecuteToggleShowPassword);
            RefreshBranding();
            RefreshConnectionSummary();
            RefreshStartupStateAsync();
        }

        public void RefreshBranding()
        {
            var settings = SystemProfileSettingsService.Load();
            var branding = SystemProfileSettingsService.BuildLoginBranding(settings);

            BrandTitle = branding.Title;
            BrandSubtitle = branding.Subtitle;
            BrandAddress = branding.Address;
            BrandInstallSerial = branding.InstallSerial;
            BrandLogoImage = LocalImageLoader.Load(branding.LogoPath);
            BrandBackgroundImage = LocalImageLoader.Load(branding.LoginBackgroundPath);
        }

        public void RefreshConnectionSummary()
        {
            var settings = ConnectionSettingsService.Load();
            var preset = settings.GetPreset(settings.SelectedPreset);
            ActiveConnectionSummary = ConnectionSettingsService.FormatPresetSummary(preset);
        }

        public void RefreshStartupStateAsync()
        {
            RefreshConnectionSummary();
            SetNeutralStatus("Preparing login. Open Connection Settings if you need to use Remote or LAN.");
            _loginCommand.RaiseCanExecuteChanged();
            _createInitialAdminCommand.RaiseCanExecuteChanged();

            Task.Run(() =>
            {
                try
                {
                    EnsureDatabaseReady();
                    using var context = new LocalDbContext();
                    var companySerialCheck = BuildCompanySerialValidationResult(context);

                    InvokeOnUiThread(() =>
                    {
                        _isCompanySerialAccessValid = companySerialCheck.IsSuccess;
                        _loginCommand.RaiseCanExecuteChanged();
                        _createInitialAdminCommand.RaiseCanExecuteChanged();

                        if (!companySerialCheck.IsSuccess)
                        {
                            IsBootstrapMode = false;
                            SetErrorStatus(companySerialCheck.Message);
                            return;
                        }

                        var state = InitialAdminSetupService.GetState(context);
                        IsBootstrapMode = state.RequiresSetup;

                        if (state.RequiresSetup)
                        {
                            SetNeutralStatus(companySerialCheck.WasBoundToDatabase
                                ? $"{companySerialCheck.Message} {state.Message}"
                                : state.Message);
                        }
                        else if (string.IsNullOrWhiteSpace(StatusMessage))
                        {
                            SetNeutralStatus(companySerialCheck.WasBoundToDatabase
                                ? companySerialCheck.Message
                                : "Sign in with an existing admin account.");
                        }
                    });
                }
                catch (Exception ex)
                {
                    InvokeOnUiThread(() =>
                    {
                        _isCompanySerialAccessValid = false;
                        _loginCommand.RaiseCanExecuteChanged();
                        _createInitialAdminCommand.RaiseCanExecuteChanged();
                        IsBootstrapMode = false;
                        SetErrorStatus($"Local database initialization failed: {ex.Message}");
                    });
                }
            });
        }

        private bool CanExecuteLogin(object? parameter)
        {
            return _isCompanySerialAccessValid &&
                   !IsBootstrapMode &&
                   !string.IsNullOrWhiteSpace(UsernameOrEmail) &&
                   !string.IsNullOrWhiteSpace(Password);
        }

        private bool CanCreateInitialAdmin(object? parameter)
        {
            return _isCompanySerialAccessValid &&
                   IsBootstrapMode &&
                   !string.IsNullOrWhiteSpace(BootstrapFullName) &&
                   !string.IsNullOrWhiteSpace(BootstrapUsername) &&
                   !string.IsNullOrWhiteSpace(BootstrapEmail) &&
                   !string.IsNullOrWhiteSpace(BootstrapPassword) &&
                   !string.IsNullOrWhiteSpace(BootstrapConfirmPassword);
        }

        private void ExecuteToggleShowPassword(object? parameter)
        {
            IsShowingPassword = !IsShowingPassword;
        }

        private void ExecuteLogin(object? parameter)
        {
            SetNeutralStatus(string.Empty);

            try
            {
                EnsureDatabaseReady();
            }
            catch (Exception ex)
            {
                SetErrorStatus($"Database connection failed. Check App Database settings. {ex.Message}");
                return;
            }

            using (var validationContext = new LocalDbContext())
            {
                var companySerialCheck = ValidateCompanySerial(validationContext);
                if (!companySerialCheck.IsSuccess)
                {
                    SetErrorStatus(companySerialCheck.Message);
                    return;
                }
            }

            var user = _authService.Login(UsernameOrEmail.Trim(), Password);

            if (user == null)
            {
                SetErrorStatus("Invalid username/email or password.");
                return;
            }

            if (user.Role != UserRole.Admin && user.Role != UserRole.SuperAdmin)
            {
                SetErrorStatus("Only authorized admin accounts can access this portal.");
                return;
            }

            UserPermissionService.LoadForUser(user);

            var dashboardWindow = new Views.MainWindow(user)
            {
                WindowStartupLocation = WindowStartupLocation.CenterScreen
            };

            Application.Current.MainWindow = dashboardWindow;
            dashboardWindow.Show();

            foreach (Window window in Application.Current.Windows)
            {
                if (window is Views.LoginWindow)
                {
                    window.Close();
                    break;
                }
            }
        }

        private void ExecuteCreateInitialAdmin(object? parameter)
        {
            SetNeutralStatus(string.Empty);

            if (!string.Equals(BootstrapPassword, BootstrapConfirmPassword, StringComparison.Ordinal))
            {
                SetErrorStatus("The admin passwords do not match.");
                return;
            }

            try
            {
                EnsureDatabaseReady();
            }
            catch (Exception ex)
            {
                SetErrorStatus($"Database connection failed. Check App Database settings. {ex.Message}");
                return;
            }

            using var context = new LocalDbContext();
            var companySerialCheck = ValidateCompanySerial(context);
            if (!companySerialCheck.IsSuccess)
            {
                SetErrorStatus(companySerialCheck.Message);
                return;
            }

            var result = InitialAdminSetupService.CreateInitialAdmin(
                context,
                new InitialAdminSetupRequest(
                    BootstrapUsername,
                    BootstrapEmail,
                    BootstrapPassword,
                    BootstrapFullName));

            if (!result.IsSuccess)
            {
                SetErrorStatus(result.Message);
                return;
            }

            UsernameOrEmail = BootstrapEmail.Trim();
            Password = string.Empty;
            BootstrapPassword = string.Empty;
            BootstrapConfirmPassword = string.Empty;
            IsBootstrapMode = false;
            SetSuccessStatus(result.Message);
        }

        private void SetNeutralStatus(string message)
        {
            StatusMessage = message;
            StatusBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#6B7280"));
        }

        private void SetSuccessStatus(string message)
        {
            StatusMessage = message;
            StatusBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#1A7A4A"));
        }

        private void SetErrorStatus(string message)
        {
            StatusMessage = message;
            StatusBrush = new SolidColorBrush((Color)ColorConverter.ConvertFromString("#991B1B"));
        }

        private static void EnsureDatabaseReady()
        {
            using var localDb = new LocalDbContext();
            localDb.Database.EnsureCreated();
            SQLiteSchemaBootstrapper.EnsureSQLiteSchema(localDb);
        }

        private CompanySerialValidationResult BuildCompanySerialValidationResult(LocalDbContext context)
        {
            _ = context;
            var localCompanySerial = (SystemProfileSettingsService.Load().InstallSerial ?? string.Empty)
                .Trim()
                .ToUpperInvariant();
            return new CompanySerialValidationResult(
                true,
                false,
                "Company serial is shown for reference only.",
                localCompanySerial);
        }

        private CompanySerialValidationResult ValidateCompanySerial(LocalDbContext context)
        {
            var result = BuildCompanySerialValidationResult(context);
            _isCompanySerialAccessValid = result.IsSuccess;
            _loginCommand.RaiseCanExecuteChanged();
            _createInitialAdminCommand.RaiseCanExecuteChanged();
            return result;
        }

        private static void InvokeOnUiThread(Action action)
        {
            if (Application.Current?.Dispatcher?.CheckAccess() ?? false)
            {
                action();
                return;
            }

            Application.Current?.Dispatcher?.Invoke(action);
        }
    }
}
