using System.Threading;
using System.Windows;
using System.Windows.Markup;

namespace AttendanceShiftingManagement.Tests;

public sealed class CashForWorkPageBindingTests
{
    [Fact]
    public void CashForWorkPage_UsesLeftRailAndWorkflowPanelBindings()
    {
        var pagePath = ResolveCashForWorkPagePath();

        var xaml = File.ReadAllText(pagePath);

        Assert.Contains("Command=\"{Binding OpenScanAttendancePanelCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding OpenPayoutPanelCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding OpenAnnouncementsPanelCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding RefreshWorkspaceCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("ItemsSource=\"{Binding SavedAttendanceRows}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("SelectedItem=\"{Binding SelectedAttendanceRow}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Visibility=\"{Binding EventEditorVisibility}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Visibility=\"{Binding ScanAttendanceVisibility}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Visibility=\"{Binding PayoutVisibility}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Visibility=\"{Binding AnnouncementsVisibility}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Visibility=\"{Binding PayoutRailVisibility}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Visibility=\"{Binding ManualAttendanceVisibility}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding SaveEventCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding SaveManualAttendanceCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding CreateAttendanceScannerSessionCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding ReleaseBudgetCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding OpenEditEventPanelCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding DeleteEventCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding EditAttendanceCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding DeleteAttendanceCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding DataContext.SelectAnnouncementEventCommand, RelativeSource={RelativeSource AncestorType={x:Type UserControl}}}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding DataContext.ShowHistoryCommand", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding SaveAttendanceSheetPdfCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Command=\"{Binding PrintAttendanceSheetCommand}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("ItemsSource=\"{Binding Participants}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("ItemsSource=\"{Binding ManualAttendanceParticipants}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Text=\"{Binding ManualAttendanceSearchText, UpdateSourceTrigger=PropertyChanged}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("ItemsSource=\"{Binding OpenAnnouncements}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Text=\"{Binding ReleaseAmountText, UpdateSourceTrigger=PropertyChanged}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Text=\"{Binding AttendanceScannerSessionUrl, Mode=OneWay}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Text=\"{Binding AttendanceScannerSessionPin}\"", xaml, StringComparison.Ordinal);
        Assert.Contains("Source=\"{Binding AttendanceScannerQrImage}\"", xaml, StringComparison.Ordinal);

        Assert.DoesNotContain("Click=\"CreateEvent_Click\"", xaml, StringComparison.Ordinal);
        Assert.DoesNotContain("Click=\"EditEvent_Click\"", xaml, StringComparison.Ordinal);
        Assert.DoesNotContain("Click=\"DeleteEvent_Click\"", xaml, StringComparison.Ordinal);
        Assert.DoesNotContain("Click=\"EditAttendance_Click\"", xaml, StringComparison.Ordinal);
        Assert.DoesNotContain("Click=\"DeleteAttendance_Click\"", xaml, StringComparison.Ordinal);
        Assert.DoesNotContain("Cash-for-Work Workspace", xaml, StringComparison.Ordinal);
        Assert.DoesNotContain("ItemsSource=\"{Binding HistoryPreviewRows}\"", xaml, StringComparison.Ordinal);
        Assert.DoesNotContain("Visibility=\"{Binding HasOpenAnnouncements, Converter={StaticResource BooleanToVisibilityConverter}}\"", xaml, StringComparison.Ordinal);
        Assert.DoesNotContain("Visibility=\"{Binding DrawerVisibility}\"", xaml, StringComparison.Ordinal);
        Assert.DoesNotContain("Click=\"OpenSettings_Click\"", xaml, StringComparison.Ordinal);
        Assert.DoesNotContain("Content=\"NEW EVENT\"", xaml, StringComparison.Ordinal);
        Assert.DoesNotContain("Visibility=\"{Binding SeminarScannerHintVisibility}\"", xaml, StringComparison.Ordinal);
        Assert.DoesNotContain("SelectedItem=\"{Binding EventEditorKind}\"", xaml, StringComparison.Ordinal);
    }

    [Fact]
    public void CashForWorkPage_XamlParsesWithoutStyleErrors()
    {
        Exception? parseException = null;

        var thread = new Thread(() =>
        {
            try
            {
                WpfTestHost.EnsureApplication();

                var pagePath = ResolveCashForWorkPagePath();

                var xaml = File.ReadAllText(pagePath)
                    .Replace("x:Class=\"AttendanceShiftingManagement.Views.CashForWorkOcrPage\"", string.Empty, StringComparison.Ordinal)
                    .Replace(" Click=\"Browse_Click\"", string.Empty, StringComparison.Ordinal)
                    .Replace("QrCodeScanned=\"Scanner_QrCodeScanned\"", string.Empty, StringComparison.Ordinal)
                    .Replace("Closed=\"Scanner_Closed\"", string.Empty, StringComparison.Ordinal)
                    .Replace("xmlns:helpers=\"clr-namespace:AttendanceShiftingManagement.Helpers\"", "xmlns:helpers=\"clr-namespace:AttendanceShiftingManagement.Helpers;assembly=AttendanceShiftingManagement\"", StringComparison.Ordinal)
                    .Replace("xmlns:local=\"clr-namespace:AttendanceShiftingManagement.Views\"", "xmlns:local=\"clr-namespace:AttendanceShiftingManagement.Views;assembly=AttendanceShiftingManagement\"", StringComparison.Ordinal);

                _ = XamlReader.Parse(xaml);
            }
            catch (Exception ex)
            {
                parseException = ex;
            }
        });

        thread.SetApartmentState(ApartmentState.STA);
        thread.Start();
        thread.Join();

        Assert.True(parseException is null, parseException?.ToString());
    }

    private static string ResolveCashForWorkPagePath()
    {
        var current = new DirectoryInfo(AppContext.BaseDirectory);

        while (current != null)
        {
            var candidate = Path.Combine(current.FullName, "Views", "CashForWorkOcrPage.xaml");
            if (File.Exists(candidate))
            {
                return candidate;
            }

            current = current.Parent;
        }

        throw new DirectoryNotFoundException("Could not locate Views\\CashForWorkOcrPage.xaml from the test output directory.");
    }
}
